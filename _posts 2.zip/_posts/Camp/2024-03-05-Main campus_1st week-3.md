---
title: 1주차 (3)
writer: Harold
date: 2024-03-05 01:11:00 +0800
categories: [캠프, 1주차]
tags: [데이터타입]

toc: true
toc_sticky: true
---

# 데이터 타입

## 1. 숫자

### 1. Int
- 정수를 표현하는 데이터 타입
- -2,147,483,648 ~ 2,147,483,647 사이 숫자를 표현할 수 있다.

```swift
var age: Int = 18 // Int 타입
```

- 참고 링크
<https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Integers>

### 2. Float
- 소수점을 표현하는 데이터 타입으로 32비트 부동 소수를 표현할 수 있다.
- Float의 정밀도는 소수점 이하 6자리까지 가능하다.

```swift
var interestRate: Float = 1.2345678910 // Float 타입
print("이자율은 \(interestRate) % 입니다")
// 출력값: 이자율은 1.2345679 % 입니다
```

- 참고 링크
<https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Floating-Point-Numbers>

### 3. Double
- 소수점을 표현하는 데이터 타입으로 64비트 부동소수를 표현할 수 있다.
- Double의 정밀도는 소수점 이하 15자리 이상 가능하다.
- 두 유형 모두 적합한 상황에서는 Double을 사용하는 것이 좋다. (출처: 공식 문서)

```swift
var interestRate: Double = 1.2345678910123456789 // Double 타입
print("이자율은 \(interestRate) % 입니다")
// 출력값: 이자율은 1.2345678910123457 % 입니다
```

- 참고 링크
<https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Floating-Point-Numbers>

## 2. 참 또는 거짓

### 1. Bool
- 참 true와 거짓 false 을 표현할 수 있는 데이터 타입.

```swift// Bool 변수 선언 및 초기화
var isOpen: Bool = true
var isLogged: Bool = false

// 조건문에서 Bool 값 사용
if isOpen {
    print("문이 열려 있습니다.")
} else {
    print("문이 닫혀 있습니다.")
}

// Bool 값을 반환하는 함수
func checkLoginStatus(isLogged: Bool) {
    if isLogged {
        print("로그인되었습니다.")
    } else {
        print("로그인되지 않았습니다.")
    }
}

// 함수 호출
checkLoginStatus(isLogged: isLogged)
```

- 참고 링크
<https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Booleans>

## 3. 문자

### 1. String
- 문자열을 표현하는 데이터 타입으로 텍스트를 표현할 수 있다.

```swift
var emptyString: String = "" 
var anotherEmptyString = String()  

var variableString = "Mom"
variableString += " and Dad"
print(variableString)
// 출력값: "Mom and Dad"
```

- 참고 링크
<https://docs.swift.org/swift-book/documentation/the-swift-programming-language/stringsandcharacters/#String-Literals>

### 2. Character
- 하나의 문자를 표현하는 데이터 타입

```swift
let catCharacters: [Character] = ["C", "a", "t", "!", "🐱"]
let catString = String(catCharacters)
print(catString)
// Prints "Cat!🐱"
```

- 참고 링크
<https://docs.swift.org/swift-book/documentation/the-swift-programming-language/stringsandcharacters/#Working-with-Characters>

## 4. 다양한 값의 묶음

### 1. Tuple
- 튜플은 여러 값을 하나로 그룹화한 값.
- Tuple은 관련 값의 단순한 그룹에 유용하다. 복잡한 데이터 구조를 만드는 데는 적합하지 않다.

```swift
let http404Error: (Int, String) = (404, "Not Found")

let (justTheStatusCode, _): (Int, String) = http404Error // _ 는 사용하지 않겠다는 의미.
print("The status code is \(justTheStatusCode)")
// 출력값: "The status code is 404"

// 튜플 값에 접근하려면 순서를 알고 있어야 한다.
print("The status code is \(http404Error.0)")
// 출력값: "The status code is 404"
print("The status message is \(http404Error.1)")
// 출력값: "The status message is Not Found"

// 각 엘레먼트에 이름을 붙일 수 있습니다.
let http200Status: (Int, String) = (statusCode: 200, description: "OK")

// 많은 데이터를 담는 데는 적합하지 않다 - 사용하는 쪽에서 또 매핑(Mapping)을 해야 함
let myInfo: (String, Int, Int, Int, String, String) = 
(name: "peter", registrationNumber: 970212, height: 185, weight: 75, job: "developer", hobby: "soccer")
```

- 참고 링크
<https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Tuples>

## 5. 모든 타입

### 1. Any
- Any는 다양한 데이터 타입의 값을 수용할 수 있다.
- Any 배열을 만들면 특정 타입의 배열이 아니라 여러 타입을 담을 수 있다.
- 하지만 Any 데이터 형을 대입하려면 반드시 형 변환이 필요하다.

```swift
var anyArray: [Any] = [1,"Hi", true]

var anyValue: Any = 1000
anyValue = "어떤 타입도 수용 가능"
anyValue = 12345.67

// 컴파일 에러
let doubleValue: Double = anyValue  // 🚨 에러 메시지: Cannot convert value of type 'Any' to specified type 'Double'
// Any 타입에 Double 값을 넣는 것은 가능하지만
// Any는 Double 과 엄연히 다른 타입이 때문에
// Double 타입의 값에 Any 타입의 값을 할당할 때에는 명시적으로 타입을 변환해 주어야 한다.
```

## 6. Swift의 Type
- Swift에서의 타입(Type)은 변수 또는 상수에 저장될 데이터의 종류를 정의하는 것이다.
- 모든 변수, 상수, 함수 매개변수, 함수 반환 값 등은 모두 특정한 타입을 가지고 있다.
- Swift는 강력한 타입 추론(Type Inference)을 지원하여 코드를 작성할 때 타입을 명시적으로 지정하지 않아도 컴파일러가 타입을 유추할 수 있는 경우가 많다.

Swift의 타입은 크게 두 가지로 나뉜다.

### 1. 기본 데이터 타입 (Built-in Data Types)
- Swift는 기본적인 데이터 타입들을 제공한다.
- 이들은 구조체로 구현되어 있으며, 각각의 타입에 해당하는 값이 메모리에 직접 저장된다.
- 주요한 기본 데이터 타입에는 다음과 같은 것들이 있다.

  - **Int**: 정수 타입 (Int8, Int16, Int32, Int64 등)
  - **UInt**: 부호 없는 정수 타입
  - **Float**: 단정도 부동 소수점 숫자 타입
  - **Double**: 배정도 부동 소수점 숫자 타입
  - **Bool**: 불리언 타입 (true 또는 false)
  - **String**: 문자열 타입
  - **Character**: 단일 문자 타입
  - 그 외 다양한 기본 데이터 타입들이 있습니다.

### 2. 사용자 정의 데이터 타입 (Custom Data Types)
- Swift에서는 개발자가 직접 타입을 정의할 수 있는 능력을 제공한다.
- 이러한 사용자 정의 데이터 타입에는 다음과 같은 것들이 있다

  - **구조체(Structures)**: 멤버 변수와 메서드를 포함하는 타입
  - **클래스(Classes)**: 객체 지향 프로그래밍을 위한 참조 타입
  - **열거형(Enumerations)**: 관련된 값들의 그룹을 정의하는 타입
  - **프로토콜(Protocols)**: 특정 작업 또는 기능에 대한 메서드, 속성 및 요구 사항을 정의하는 타입

사용자 정의 데이터 타입은 프로그램에서 특정한 목적을 위해 데이터를 묶고 구조화하는 데 사용된다.

이러한 타입들을 사용하여 코드를 조직화하고 데이터 모델을 만들어 유연하고 확장 가능한 앱을 개발하는 데 도움이 된다.

타입은 Swift 언어의 핵심 요소 중 하나이며, 안정성과 코드의 가독성을 높이는 데 중요한 역할을 한다.

#### 1. 타입 추론

- 타입을 지정하지 않아도 **컴파일러**가 타입을 유추해주어 지정(변수명 위에 option버튼 누르고 마우스 클릭하면 타입을 볼 수 있음)
- 컴파일러란?
    
    Swift 컴파일러는 Swift 프로그램을 작성한 코드를 컴퓨터가 이해할 수 있는 실행 가능한 형태로 변환해주는 프로그램이다. 이 변환 과정은 크게 소스 코드를 분석하고, 그것을 기계어로 번역하는 단계로 이루어진다.
    
    1. **소스 코드 분석:**
        - Swift 컴파일러는 코드를 읽고 문법적인 구조로 분해한다. 이 때, 코드의 토큰(Token) 단위로 나누어짐.
        - 그리고 이 토큰들을 이용하여 코드의 구조를 이해하고 추상적인 트리 모양의 구조를 생성.
    2. **의미 분석:**
        - 코드의 의미와 상호 작용을 이해하고 검증한다. 변수 선언, 함수 호출 등이 올바르게 이루어졌는지 확인.
        - 이 과정에서 타입 체크(Type Checking)와 같은 작업이 이루어져 코드의 안정성을 확인한다.
    3. **코드 최적화:**
        - 코드를 실행할 때 속도를 향상시키고 메모리를 효율적으로 사용하기 위해 최적화 작업을 수행.
        - 이 최적화는 코드 실행 성능을 높이고, 실행 파일의 크기를 줄이는 데 도움이 된다.
    4. **코드 생성:**
        - 최종적으로 최적화된 코드를 목표 플랫폼(예: iOS, macOS 등)에서 실행할 수 있는 기계어로 변환.
        - 이렇게 생성된 실행 파일은 해당 플랫폼에서 실행되어 우리가 작성한 Swift 프로그램을 실행한다.

Swift 컴파일러는 이러한 과정을 거쳐 우리가 작성한 코드를 실행 가능한 형태로 만들어주는 역할을 한다. 이는 우리가 Swift로 작성한 프로그램을 컴퓨터에서 실행할 수 있도록 해준다.

```swift
var weight = 90
type(of: weight) // Int.Type

var language = "Swift"
type(of: language) // String.Type
```

#### 2. 타입 안정성
- 데이터 타입을 명확하게 사용하고, 다른 타입끼리의 연산이 불가능하다

```swift
var integer = 5
var double = 3.1

integer = double -> 불가능

integer + double -> 불가능
```

#### 3. 타입 형변환
- 형변환이 가능하다.

```swift
let integerString = "321"
let number = Int(integerString)

print(number) // 321

let doubleString = "321.2"
let number2 = Int(doubleString)

print(number2) // nil -> 추후 학습 예정. 값이 없음을 표현
```